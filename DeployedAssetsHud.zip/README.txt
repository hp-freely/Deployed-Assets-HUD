////
// The purpose of this script is to provide a HUD which displays a true and accurate count of deployed assets for the user's current team. There used to be
// a couple of scripts developed by ilys (ex: Team Asset Finder) that accomplished this as well. However, ilys' script stopped functioning very early in the 
// history of T2, because it relied on a core T2 function, and the data reported by the function changed at some point. I don't know exactly when, but my hunge is 
// when Classic was released. Since that time, the only other option has been the Engineer's HUD script, which is a terrible alternative.
//
// This script uses some core logic approaches which were developed by ilys. However, I decided to rewrite the script, because a) ilys' original script was a terrible
// kludge of code that was madness to reverse engineer, and b) the original script contained a bunch of additional fucntionality that is simply not useful.
//
// The above context provided, here is an overview of how this script works.
//
// First, you must be aware that T2 does *not* make it simple to reference the current count of assets. In fact, it requires a large number of workarounds, and it 
// forces a few restrictions on the user, which is not ideal. (These restrictions are detailed at the bottom). I personally think it's silly that a) the original devs
// didn't make this data more easily available, and b) no one from the community wanted to surface this information to users either.
//
// The core logic of the script can be described as follows:
// - The script maintains a *global* loop that is always analyzing the latest set of deployed object data.
// - The script retrieves deployed asset information from the CC. However, this information is *only* updated when the CC is opened. This means that the script must
//   continously focus the CC *behind the scenes* in order to get the latest deployed asset data. This also means that the script must ensure that focusing the CC
//   does not interfere with the user's normal behavior.
// - While the CC does given you access to deployed objects, it *does not* give you any context about what a given object is (ex: deployed inven vs spike turret vs pulse
//   sensor). In order to get this information, the script must create a task for that object (ex: Defend Object or Repair Object). Then, the script must reference an
//   overridable task function, clientCmdTaskInfo(), and *that* function will actually give us context on what that object is.
// - The presents an issue where a) the script must wait on the task creation callback, but b) the script must *not* create a task for *any other object* until the callback
//   has been processed. Else, we run into race conditions where a *second* object might be evaluated from the CC before the *first* object was processed. This is why the 
//   script must maintain a *global* loop. It's a very delicate balance.
// - Finally, there a bunch of small, nuanced conditions that must be handled as well as a result of the complicated structure described above.
//
// In order to support this script, there are a few restrictions that must be forced on the user. I feel these restrictions are small, but only the user can make that
// judgement. The restrictions are as follows:
// - The script completely removes the ability to create a "Defend Object" task for objects. I chose the "Defend Object" task to be used when creating a task for a deployed
//   object from the CC (as described in the above section). T2 forces me to use a core, supported task option. Otherwise, the callback functions won't work as I need them
//   to. Given this, the only other option was the "Repair Object" option. I chose "Defend Object", because it is probably the least likely to be used these days. 
// 
//   The reason I need to remove "Defened Object" is because the script *cannot* have a user accidentally calling it. The issue is: a) the CC provides the Object ID, and b)
//   the callback task function provides the object name. However, *neither* provide both. If a user creates a "Defend Object" task, and the script also creates a task
//   for an object, then a race condition could occur where the script tracks the *wrong* object. I would consider this even to be rare, but there's no reason not to
//   to prevent it.
//
// - This is probably the most annoying item. As described above, the script must create a task in order to get context on an object. When that task is created, the user will
//   see a square green icon display *in-game* on that object. This is the standard green icon used by T2. There is *no way* to prevent this from happening. This action
//   is core to the server-side serverCmdSendTaskToClient() function.
//
//   This is annoying for two reasons: 
//      1) Every time any person deploys an asset, a green icon will be displayed. This can result in a lot of noise, where you may not be certain if you need to pay attention
//         to that icon. This especially egregious when you join a team, where that team has a lot of deployed assets. For example, if they have 20 assets, you will necessarily
//         see 20 green icons popup.
//      2) The green icon is *supposed* to have no words associated with - it's just a blank icon. However, T2 seems to have some bug with appropriately displaying the name 
//         of a tasks. You see this with BuddyPoints a lot. I have found that, sometimes, when a green icon shows show on an asset, it will show an actual name of a player 
//         or object. This name is a reference to a *previous task*. I don't know how to prevent this from happening.
//
// - The script will never allow the CC to be displayed in demos. The reason for this is, as described in the above section, the script must be able to continuously focus
//   the CC in order get updated deployed asset data. When the user is playing the game, this focus action happens behind the scenes, and the user isn't aware of it.
//   However, for reasons I don't understand, this "behind the scenes" action does not work in demos. As a result, if a special action is not taken, then the CC would
//   *always* be displayed in the demo. I feel this is a very small restriction to deal with.
//
//   This behavior is actually the *exact same* behavior as the "AutoCloseDemoCC" option provided by Kaiten's zSCRIPT-Recordings.vl2 script.
//
// - Deployed Asset HUD will *not* be displayed when viewing a demo. The reason for this is purely mechanical. When a user views a demo, they are doing so from the
//   perspective of an observer. In other words, the user has *no active team* when viewing a demo. Demos process game information as if a given action was happening in
//   real time. Demos *do not record* actions. As a result, since the user is an observer, they have no access to CC asset information for a given team.
//
// *FINAL IMPORTANT Note:* 
// Updating the count of assets in the HUD is not necessarily immediate. It depends on a number of factors. For example, consider a worst case scenario: A team currently has
// a large number of deployed asset objects (ex: 20+). The user of the script then joins that team. The script has to a) loop through each of those objects, b) create a task
// and process that object, and finally c) after looping through all objects, update the HUD count. This could take 5 seconds or more.
//
// Simiarly, if a large number of assets were destroyed from one mortar shot, you might have to wait an amount of time for the counts to be updated as well. This is just a
// reality of the workaround required to get a count in the first place.
////

Dependencies
You must ensure you support the following dependencies:
1. HudManager.vl2
2. UberGuy's Script Suite. 
   (I am unsure what supports this. This must include: a) Scripts tab in the browser, b) UberPrefs support. Both of the these are included in the all-in-one download.)
	
Instructions
1. Move DeployedAssetsHud.vl2 to your z_scripts or scripts folder
2. Move prefs/DeployedAssetsHudPrefs.cs to your base/prefs folder
3. Use the browser Script tab to set the HUD configuration, if desired.
4. Use the prefs file to configure HUD style and the HUD prefix text, if desired.
5. After loading a map, use HudMover to position the HUD as needed: 
    - "Deployed Assets HUD" 