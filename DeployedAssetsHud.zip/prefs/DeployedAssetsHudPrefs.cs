////
// Deployed Assets HUD is configured in two locations:
//   1) The in-game Options tab allows you to configure the one item that you might want to change on the fly.
//   2) This prefs file allows you to configure all other items associated with the script.
////

	// the following list of game modes supports deploying / tracking assets. If any game mode is missing, then it can be simply added to
	// the bottom of this list, and it will be dynamically supported.
DeployedAH.supportedGameModes[0] = "Arena";
DeployedAH.supportedGameModes[1] = "CTF";
DeployedAH.supportedGameModes[2] = "Capture the Flag";		
DeployedAH.supportedGameModes[3] = "Capture the Flag (Practice)";
DeployedAH.supportedGameModes[4] = "Capture and Hold";
DeployedAH.supportedGameModes[5] = "Conquest";
DeployedAH.supportedGameModes[6] = "Defend and Destroy";
DeployedAH.supportedGameModes[7] = "Deathmatch";
DeployedAH.supportedGameModes[8] = "Hybrid";
DeployedAH.supportedGameModes[9] = "Siege";
DeployedAH.supportedGameModes[10] = "Team Deathmatch";


// ------ Look and Feel Profiles ------------ //
/////
// I feel there are really only two ways present this:
// Profile 1: Long Label
// This profile displays longer descriptive text for each asset type label.
//
// Profile 2: Short Label
// This profile displays abbreviated text for each asset type label.
//
// If you want to use a given profile, then just appropriately comment / uncomment the lines below.
///// 


//// Profile 1: Long Label

	// the label text that will be displayed before each asset type
DeployedAH.DeployedAssetsHUD_Deployed_Inven_Label_Text = "Inven: ";
DeployedAH.DeployedAssetsHUD_Spike_Turret_Label_Text = "Spike: ";
DeployedAH.DeployedAssetsHUD_Clamp_Turret_Label_Text = "Clamp: ";
DeployedAH.DeployedAssetsHUD_Pulse_Sensor_Label_Text = "Pulse: ";
DeployedAH.DeployedAssetsHUD_Motion_Sensor_Label_Text = "Motion: ";
DeployedAH.DeployedAssetsHUD_Camera_Label_Text = "Cam: ";

	// The Horizontal HUD will display asset information in 3 columns by 2 rows. The variables below set the
	// X position of the asset labels and asset count values within each column.
	//
	// The script dynamically sets a given asset to a given position, depending on which are configured to be displayed
	// by the user. The order is: Inven, Camera, Spike, Clamp, Pulse, Motion
DeployedAH.DeployedAssetsHUD_Horizontal_Column_1_X_Label_Position = 6;
DeployedAH.DeployedAssetsHUD_Horizontal_Column_1_X_Count_Position = 48;		
DeployedAH.DeployedAssetsHUD_Horizontal_Column_2_X_Label_Position = 72;
DeployedAH.DeployedAssetsHUD_Horizontal_Column_2_X_Count_Position = 115;
DeployedAH.DeployedAssetsHUD_Horizontal_Column_3_X_Label_Position = 136;
DeployedAH.DeployedAssetsHUD_Horizontal_Column_3_X_Count_Position = 181;

	// The Y position of the rows associated with the Horizontal HUD
DeployedAH.DeployedAssetsHUD_Horizontal_Row_1_Y_Position = 3;
DeployedAH.DeployedAssetsHUD_Horizontal_Row_2_Y_Position = 19;

	// Width and Height variables that add padding to the HUD after the last column and row are displayed in the Horizontal HUD, respectively.
DeployedAH.DeployedAssetsHUD_Horizontal_Dynamic_Width_Extension = 20;
DeployedAH.DeployedAssetsHUD_Horizontal_Dynamic_Height_Extension = 16;

	// The Vertical HUD will display asset information in 1 columns by 6 rows. The variables below set the
	// X position of the asset labels and asset count values within that column
	//
	// The script dynamically sets a given asset to a given position, depending on which are configured to be displayed
	// by the user. The order is: Inven, Camera, Spike, Clamp, Pulse, Motion	
DeployedAH.DeployedAssetsHUD_Vertical_X_Label_Position = 6;
DeployedAH.DeployedAssetsHUD_Vertical_X_Count_Position = 48;

	// The Y position of the rows associated with the Vertical HUD
DeployedAH.DeployedAssetsHUD_Vertical_Row_1_Y_Position = 3;
DeployedAH.DeployedAssetsHUD_Vertical_Row_2_Y_Position = 19;
DeployedAH.DeployedAssetsHUD_Vertical_Row_3_Y_Position = 35;
DeployedAH.DeployedAssetsHUD_Vertical_Row_4_Y_Position = 51;
DeployedAH.DeployedAssetsHUD_Vertical_Row_5_Y_Position = 67;
DeployedAH.DeployedAssetsHUD_Vertical_Row_6_Y_Position = 83;

	// Height variables that add padding to the HUD after the last row is displayed in the Vertical HUD.
	// Note: It is not necessary to defined a dynamic width padding, because there is only one column.
DeployedAH.DeployedAssetsHUD_Vertical_Dynamic_Height_Extension = 16;

	// The width and height of the asset labels and count values.
DeployedAH.DeployedAssetsHUD_Item_Label_Text_Width = 40;
DeployedAH.DeployedAssetsHUD_Item_Label_Text_Height = 15;
DeployedAH.DeployedAssetsHUD_Item_Count_Text_Width = 40;
DeployedAH.DeployedAssetsHUD_Item_Count_Text_Height = 15;

	// the font style configuration of the asset labels and count values.
DeployedAH.DeployedAssetsHUD_Label_Text_Font_Name = "Supertouch";
DeployedAH.DeployedAssetsHUD_Label_Text_Font_Size = "14";
DeployedAH.DeployedAssetsHUD_Label_Text_Font_Color = "169 215 250";
DeployedAH.DeployedAssetsHUD_Count_Text_Font_Name = "Supertouch";
DeployedAH.DeployedAssetsHUD_Count_Text_Font_Size = "14";
DeployedAH.DeployedAssetsHUD_Count_Text_Font_Color = "169 215 250";



//// Profile 2: Short Label

	// the label text that will be displayed before each asset type
// DeployedAH.DeployedAssetsHUD_Deployed_Inven_Label_Text = "IN: ";
// DeployedAH.DeployedAssetsHUD_Spike_Turret_Label_Text = "ST: ";
// DeployedAH.DeployedAssetsHUD_Clamp_Turret_Label_Text = "CT: ";
// DeployedAH.DeployedAssetsHUD_Pulse_Sensor_Label_Text = "PS: ";
// DeployedAH.DeployedAssetsHUD_Motion_Sensor_Label_Text = "MS: ";
// DeployedAH.DeployedAssetsHUD_Camera_Label_Text = "CA: ";

	// The Horizontal HUD will display asset information in 3 columns by 2 rows. The variables below set the
	// X position of the asset labels and asset count values within each column.
	//
	// The script dynamically sets a given asset to a given position, depending on which are configured to be displayed
	// by the user. The order is: Inven, Camera, Spike, Clamp, Pulse, Motion
// DeployedAH.DeployedAssetsHUD_Horizontal_Column_1_X_Label_Position = 6;
// DeployedAH.DeployedAssetsHUD_Horizontal_Column_1_X_Count_Position = 33;		
// DeployedAH.DeployedAssetsHUD_Horizontal_Column_2_X_Label_Position = 58;
// DeployedAH.DeployedAssetsHUD_Horizontal_Column_2_X_Count_Position = 85;
// DeployedAH.DeployedAssetsHUD_Horizontal_Column_3_X_Label_Position = 110;
// DeployedAH.DeployedAssetsHUD_Horizontal_Column_3_X_Count_Position = 137;


	// The Y position of the rows associated with the Horizontal HUD
// DeployedAH.DeployedAssetsHUD_Horizontal_Row_1_Y_Position = 3;
// DeployedAH.DeployedAssetsHUD_Horizontal_Row_2_Y_Position = 19;

	// Width and Height variables that add padding to the HUD after the last column and row are displayed in the Horizontal HUD, respectively.
// DeployedAH.DeployedAssetsHUD_Horizontal_Dynamic_Width_Extension = 20;
// DeployedAH.DeployedAssetsHUD_Horizontal_Dynamic_Height_Extension = 16;

	// The Vertical HUD will display asset information in 1 columns by 6 rows. The variables below set the
	// X position of the asset labels and asset count values within that column
	//
	// The script dynamically sets a given asset to a given position, depending on which are configured to be displayed
	// by the user. The order is: Inven, Camera, Spike, Clamp, Pulse, Motion	
// DeployedAH.DeployedAssetsHUD_Vertical_X_Label_Position = 6;
// DeployedAH.DeployedAssetsHUD_Vertical_X_Count_Position = 33;

	// The Y position of the rows associated with the Vertical HUD
// DeployedAH.DeployedAssetsHUD_Vertical_Row_1_Y_Position = 3;
// DeployedAH.DeployedAssetsHUD_Vertical_Row_2_Y_Position = 19;
// DeployedAH.DeployedAssetsHUD_Vertical_Row_3_Y_Position = 35;
// DeployedAH.DeployedAssetsHUD_Vertical_Row_4_Y_Position = 51;
// DeployedAH.DeployedAssetsHUD_Vertical_Row_5_Y_Position = 67;
// DeployedAH.DeployedAssetsHUD_Vertical_Row_6_Y_Position = 83;

	// Height variables that add padding to the HUD after the last row is displayed in the Vertical HUD.
	// Note: It is not necessary to defined a dynamic width padding, because there is only one column.
// DeployedAH.DeployedAssetsHUD_Vertical_Dynamic_Height_Extension = 16;

	// The width and height of the asset labels and count values.
// DeployedAH.DeployedAssetsHUD_Item_Label_Text_Width = 20;
// DeployedAH.DeployedAssetsHUD_Item_Label_Text_Height = 15;
// DeployedAH.DeployedAssetsHUD_Item_Count_Text_Width = 20;
// DeployedAH.DeployedAssetsHUD_Item_Count_Text_Height = 15;


	// the font style configuration of the asset labels and count values.
// DeployedAH.DeployedAssetsHUD_Label_Text_Font_Name = "Supertouch";
// DeployedAH.DeployedAssetsHUD_Label_Text_Font_Size = "14";
// DeployedAH.DeployedAssetsHUD_Label_Text_Font_Color = "169 215 250";
// DeployedAH.DeployedAssetsHUD_Count_Text_Font_Name = "Supertouch";
// DeployedAH.DeployedAssetsHUD_Count_Text_Font_Size = "14";
// DeployedAH.DeployedAssetsHUD_Count_Text_Font_Color = "169 215 250";